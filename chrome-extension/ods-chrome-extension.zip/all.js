chrome.browserAction.onClicked.addListener(function (tab) {
    chrome.tabs.executeScript({file: "toggle-show-hide.js"});
});


chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    chrome.browserAction.setIcon({
        path: request.newIconPath,
        tabId: sender.tab.id
    });
    chrome.browserAction.setTitle({
        title: "No Opendatasoft portal detected. Extension disabled."
    })
});

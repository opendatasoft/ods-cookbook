chrome.browserAction.onClicked.addListener(function(tab) {
    chrome.tabs.executeScript({file:"toggle-show-hide.js"});
});

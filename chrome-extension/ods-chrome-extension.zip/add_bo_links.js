var list = document.getElementById("ods-helper-list");
if (list == null) {
    list = document.createElement("div");
    list.id = "ods-helper-list";
} else {
    list.appendChild(document.createElement("hr"));
}

re = /.*\/backoffice\/.*/;

var newpage = document.createElement("a");
newpage.innerHTML='<i title="New page" class="fa fa-file-o" aria-hidden="true"></i>';
newpage.id="ods-helper-list-newpage"
newpage.href="/backoffice/pages/new/";
list.appendChild(newpage);

var newds = document.createElement("a");
newds.innerHTML='<i title="New dataset" class="fa fa-database" aria-hidden="true"></i>';
newds.id="ods-helper-list-newds"
newds.href="/backoffice/catalog/datasets/new/";
list.appendChild(newds);

list.appendChild(document.createElement("hr"));

var switchside = document.createElement("a");
switchside.id="ods-helper-list-switch"
if (window.location.pathname.search(re) >= 0) { // if on backoffice side, go back to front
    switchside.innerHTML='<i title="Go back to the frontoffice" class="fa fa-reply" aria-hidden="true"></i>';
    switchside.href="/";
} else { // front to back
    switchside.innerHTML='<i title="Go to the backoffice" class="fa fa-reply" aria-hidden="true"></i>';
    switchside.href="/login/?next=/backoffice/";
}

list.appendChild(switchside);


document.body.appendChild(list); 

var list = document.getElementById("ods-helper-list");
list.classList.toggle("ods-helper-hide");
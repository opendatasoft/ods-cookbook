var list = document.getElementById("ods-helper-list");

if (list) {
    list.classList.toggle("ods-helper-hide");
}

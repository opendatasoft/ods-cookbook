var yargs = require('yargs');
var argv = yargs.argv;
try {
    var config = require('./config');
} catch (ex) {
    if (ex.code === 'MODULE_NOT_FOUND') {
        console.error('\x1b[31m', '!!! config.js doest not exists ! Before starting, copy config.example.js to config.js and fill in your parameters\n' +
            'To do so, copy/paste the following command : \n\t\t cp config.example.js config.js')
    } else {
        console.error('\x1b[31m', '!!! config.js error, check the stack to fix it')
        console.error(ex);
    }
    process.exit(1);
}

var gulp = require('gulp');
var git = require('gulp-git');

var del = require('del');
gulp.task('clean', function () {
    return del([config.OUTPUT_DIR, 'tmp']);
});

/* SERVER */
var gls = require('gulp-live-server');
var browserSync = require('browser-sync');

var expressapp = function (done) {
    var server = gls.new(['./app.js', '--port', config.SERVER_PORT]);
    server.start();
    done();
};

var browsersync = function (done) {
    browserSync.init(null, {
        proxy: "http://localhost:" + config.SERVER_PORT,
        files: config.WATCH_DIRS,
        browser: config.BROWSER,
        port: (1 * config.SERVER_PORT + 1),
    });
    done();
};

gulp.task('server', gulp.series(expressapp, browsersync));

/* HTML */
var ejs = require('gulp-ejs');
const rename = require('gulp-rename');

gulp.task('compile-html', function () {
    return gulp.src(argv.ejsfile || config.DEFAULT_EJSFILE)
        .pipe(ejs({}))
        .pipe(rename({extname: '.html'}))
        .pipe(gulp.dest(config.OUTPUT_DIR));
});

/* LESS CSS */
var less = require('gulp-less');
var path = require('path');

gulp.task('compile-css', function () {
    return gulp.src(argv.lessfile || config.DEFAULT_LESSFILE)
        .pipe(less({
            paths: [path.join(__dirname, 'static', 'spreadsheets')]
        }))
        .pipe(gulp.dest(config.OUTPUT_DIR));
});

gulp.task('compile', gulp.series('compile-html', 'compile-css'));

/* API Managment */
var request = require('request');
var fs = require('fs');

gulp.task('get', function (cb) {
    request.get({
        url: 'https://' + config.ODS_PORTAL_DOMAIN_ID + config.ODS_PORTAL_SUFFIX + '/api/management/v2/pages/' + config.PAGE_ID,
        auth: {
            'user': config.ODS_USERNAME,
            'pass': config.ODS_PASSWORD
        }
    }, function (error, response, body) {
        if (error || !body) throw error
        fs.mkdir(path.join(__dirname, 'tmp'), { recursive: true }, (err) => {if(err) throw err;});
        fs.writeFileSync(path.join(__dirname, 'tmp', 'pages.json'), body);
        cb();
    })
});

var jeditor = require("gulp-json-editor");

gulp.task('edit', function (cb) {
    return gulp.src(path.join(__dirname, 'tmp', 'pages.json'))
        .pipe(jeditor(function (json) {
            json.slug = undefined;
            json.pushed_by_parent = undefined;
            json.has_subdomain_copies = undefined;
            json.created_at = undefined;
            json.last_modified = undefined;
            json.last_modified_user = undefined;
            json.author = undefined;
            Object.keys(json.content.main.text).forEach(function(key) {
                json.content.main.text[key] = fs.readFileSync(path.join(__dirname, config.OUTPUT_DIR, config.DEFAULT_OUTPUT_HTML_FILE), "utf8");
                json.content.custom_css.text[key] = fs.readFileSync(path.join(__dirname, config.OUTPUT_DIR, config.DEFAULT_OUTPUT_CSS_FILE), "utf8");
            })
            return json;
        }))
        .pipe(gulp.dest(path.join(__dirname, 'tmp')))
});


var through2 = require('through2');

gulp.task('put', function (cb) {
    gulp.src(path.join(__dirname, 'tmp', 'pages.json'))
        .pipe(through2.obj(function(file, enc, cb) {
                // Prepare the payload
                request.put({
                    url: 'https://' + config.ODS_PORTAL_DOMAIN_ID + config.ODS_PORTAL_SUFFIX + '/api/management/v2/pages/' + config.PAGE_ID,
                    auth: {
                        'user': config.ODS_USERNAME,
                        'pass': config.ODS_PASSWORD
                    },
                    json: JSON.parse(file.contents.toString()),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                }, function (error, response, body) {
                    if (error) {
                        console.log(error);
                    }
                    if (response) {
                        console.log(response.body);
                    }
                    cb();
                })
            }
        ));
    cb();
});

gulp.task('update', gulp.series('clean', 'get', 'compile', 'edit', 'put'));


/* Versionning */

/*
git checkout master
git branch xxx
git checkout xxx
git commit -m "init"
git push --set-upstream origin xxx
 */
gulp.task('newproject', async function(done){
    if (!argv.name) {
        console.error('\x1b[31m', 'A project name must be provided, for example : \n\t gulp newproject --name home-data');
        return;
    }
    git.checkout("master", function (err) {
        if (err) {
            throw err;
        } else {
            git.branch(argv.name, function (err) {
                if (err) {
                    if (err.code == 128) {
                        console.error('\x1b[31m', "Project '" + argv.name + "' already exists, load it or choose another name");
                        return;
                    }
                } else {
                    git.checkout(argv.name, function (err) {
                        if (err) {
                            throw err;
                        } else {
                            git.commit('initial commit', {args: '-a'}, function (err) {
                                    if (err) {
                                        throw err;
                                    } else {
                                        git.push('origin', argv.name, {args: '--set-upstream'}, function (err) {
                                            if (err) {
                                                throw err;
                                            } else {
                                                console.log('Project created !');
                                                done();
                                            }
                                        });
                                    }
                            })
                        }
                    });
                }
            });
        }
    });
});

gulp.task('loadproject', async function(done){
    git.checkout(argv.name, function (err) {
        if (err) {
            if (err.code == 128) {
                console.error('\x1b[31m', "Project '" + argv.name + "' does not exists");
                return;
            } else {
                throw err;
            }
        }
        done();
    });
});

/*gulp.task('listprojects', function(done){
    git.showBranch({'args': '--list'}, function (err) {
        if (err) {
            throw err;
        } else {
            done();
        }
    })
});*/

var log = require('fancy-log');
var exec = require('child_process').exec;

gulp.task('listprojects', function (done) {
    var cwd = process.cwd();
    var args = '--list';
    var cmd = 'git show-branch ' + args;
    return exec(cmd, {cwd: cwd}, function(err, stdout, stderr) {
        if (err) return cb(err);
        log(stdout, stderr);
    });
});

var commit = function () {
    return gulp.src('.').pipe(git.add()).pipe(git.commit(argv.comment, {args: ''}, function (err) {
        if (err) throw err;
    }));
};

var push = function(done) {
    git.push('origin', function (err) {
        if (err) {
            throw err;
        } else {
            console.log('\x1b[32m', 'Project saved');
            done();
        }
    });
};

/*
git commit -a -m "MSG"
git push
 */
gulp.task('save', async function(done) {
    if(!argv.comment || argv.comment === true) {
        console.error('\x1b[31m', 'Your save must contain a comment between quotes,\n\t gulp save --comment "ici ou là bas"');
        return;
    }
    gulp.series(commit, push)();
});




gulp.task('default', function(done) {
   console.log("\n-- Welcome to Opendatasoft local development kit --\n");
   console.log("\t Main commands are :\n");
   console.log("\t> gulp server (to run the local server and run your work");
   console.log("\t> gulp update (to upload your work on your Opendatasoft portal, don't forget to add your settings in config.js");
   console.log("\t> gulp newproject > gulp loadproject > gulp listprojects > gulp save (to save keep tracks of your changes)");
   console.log("\t> gulp --tasks (to see all available tasks)");
   console.log("\n");
   done();
});
(function () {
    'use strict';
    var mod = angular.module('ods-widgets');

    function parseUrl( url ) {
        var a = document.createElement('a');
        a.href = url;
        return a;
    }

    mod.directive('odsTabs', function () { 
        /**
         * @ngdoc directive
         * @name ods.core.directive:odsPane
         * @scope
         * @restrict E
         *
         * @param {string} name The name of this tabs component (will be used in selection events).
         * @param {string} defaultTab The name of the default tab (shown at initialization).
         *
         * @param {string} [syncToURL='true'] Whether to synchronize the current active tab in the URL or not. Either 'true' or 'false'.
         * @param {string} [syncToURLMode='hash'] The way the tab should be synchronized within the URL. Either 'path' or 'hash'.
         * @param {string} [pathPrefix=''] A prefix to add to the path when URL synchronization is enabled and mode is set to 'path'
         * @param {object} [syncToObject] If set, then the name of the current active tab will be saved in the given object, under the 'tab' property.
         * @param {string} [layout='horizontal'] The style of the tabs component. Can be either 'horizontal' or 'simple-nav' (a simpler, more compact style)
         * @param {boolean} [collapsible=false] Whether panes can be collapsed upon a second click on the their respective tabs.
         * @param {boolean} [defaultCollapsed=false] The default collapsed state at initialization.
         */
        return {
            restrict: 'E',
            transclude: true,
            scope: {
                syncToUrl: '@',
                syncToUrlMode: '@',
                syncToObject: '=',
                pathPrefix: '=?',
                name: '@',
                layout: '@?',
                collapsible: '=?',
                defaultCollapsed: '=?',
                defaultTab: '@'
            },
            template: '' +
            '<div class="ods-tabs" ng-show="panes.length" role="tablist">' +
            '    <div class="ods-tabs__tabs">' +
            '        <a href=""' +
            '           ng-click="selectTab(pane, true)"' +
            '           ng-keypress="checkKey($event, pane)"' +
            '           ng-repeat="pane in panes"' +
            '           ng-class="{\'ods-tabs__tab--active\': pane.selected,' +
            '                      \'ods-tabs__tab--horizontal\': !layout || layout == \'horizontal\',' +
            '                      \'ods-tabs__tab--simple-nav\': layout == \'simple-nav\'}"' +
            '           class="ods-tabs__tab {{ pane.slug }} {{ pane.tabClass }}"' +
            '           ng-hide="pane.hidden"' +
            '           role="tab">' +
            '            <i ng-show="pane.icon" class="fa fa-{{ pane.icon }}" aria-hidden="true"></i>' +
            '            {{ pane.title }}' +
            '            <span ng-if="pane.count|isDefined">({{pane.count}})</span>' +
            '        </a>' +
            '    </div>' +
            '    <div ng-transclude></div>' +
            '</div>',
            replace: true,
            controller: ['$scope', '$location', '$element', function ($scope, $location, $element) {
                var panes = $scope.panes = [];
                var selectedIndex;
                $scope.syncToUrlMode = $scope.syncToUrlMode === 'path' ? 'path' : 'hash';
                $scope.pathPrefix = $scope.pathPrefix || '';
                $scope.linkingDone = false;

                // init collapsible mode
                $scope.collapsible = ($scope.collapsible === true);
                $scope.defaultCollapsed = ($scope.defaultCollapsed === true);

                $scope.checkKey = function(event, pane){
                    if (event.keyCode === 13){
                        $scope.selectTab(pane, true);
                    }
                };

                $scope.selectTab = function (pane, userSelection) {
                    if (!pane.selected) {
                        angular.forEach(panes, function (p) {
                            p.selected = false;
                        });
                        pane.selected = true;

                        if ($scope.syncToUrl !== 'false') {
                            if (!userSelection) {
                                $location.replace(); // replace history
                            }
                            if ($scope.syncToUrlMode === 'hash') {
                                $location.hash(pane.slug);
                            } else {
                                $location.path($scope.pathPrefix + pane.slug + '/');
                            }
                        }

                        if ($scope.syncToObject && !defaultSelection) {
                            $scope.syncToObject.tab = pane.slug;
                        }

                        selectedIndex = $.map(panes, function (p) {
                            return p.selected;
                        }).indexOf(true);

                        $scope.$emit('tabSelected', {'tabsName': $scope.name, 'selection': pane.slug});
                    } else if ($scope.collapsible) {
                        angular.forEach(panes, function (p) {
                            p.selected = false;
                        });
                    }
                    $element.find('a.ods-tabs__tab.'+pane.slug).blur();
                };

                this.selectTab = $scope.selectTab;
                this.addPane = function (pane, index) {
                    if (angular.isUndefined(index)) {
                        panes.push(pane);
                    } else {
                        panes.splice(index, 0, pane);
                    }

                    if ($scope.linkingDone && typeof selectedIndex === "undefined") {
                        // we are getting there after the initial setup so we need to make sure a tab is actually selected
                        $scope.selectTab(pane);
                    }
                };
                $scope.$on('selectTab', function (e, name, slug) {
                    if (name === $scope.name) {
                        $scope.selectTab(panes.filter(function (p) {
                            return p.slug === slug;
                        })[0], false);
                    }
                });

                $scope.selectDefaultTab = function() {
                    if (!($scope.collapsible && $scope.defaultCollapsed)) {
                        var pane;
                        if ($scope.syncToUrl !== 'false') {
                            pane = extractPaneFromUrl($location.url());
                        }

                        if (!pane && $scope.defaultTab) {
                            angular.forEach($scope.panes, function(p) {
                                if (!pane && $scope.defaultTab === p.slug) {
                                    pane = p;
                                }
                            });
                        }

                        if (!pane) {
                            pane = $scope.panes[0];
                        }

                        if (pane) {
                            $scope.selectTab(pane, false);
                        }
                    }
                };

                // select first pane visible
                $scope.$watch(function () {
                    return $.map(panes, function (p) {
                        return p.visible;
                    });
                }, function (nv, ov) {
                    // is the currently selected pane visible ?
                    if ($scope.panes[selectedIndex] && !$scope.panes[selectedIndex].visible) {
                        if (nv && nv.indexOf(true) >= 0) {
                            $scope.select($scope.panes[nv.indexOf(true)]);
                        }
                    }
                }, true);

                this.getLayout = function () {
                    return angular.isDefined($scope.layout) ? $scope.layout : 'horizontal';
                };

                var extractPaneFromUrl = function(url) {
                    var paneSlug, pane;
                    if ($scope.syncToUrlMode === 'hash') {
                        paneSlug = parseUrl(url).hash.replace("#", "");
                    } else {
                        var urlParts = parseUrl(url).pathname.split('/');
                        paneSlug = urlParts[urlParts.length - 2];
                    }

                    angular.forEach($scope.panes, function(p) {
                        if (!pane && paneSlug === p.slug) {
                            pane = p;
                        }
                    });

                    return pane;
                };

                if ($scope.syncToUrl !== 'false') {
                    $scope.$on('$locationChangeSuccess', function (e, newUrl, oldUrl) {
                        var newPane = extractPaneFromUrl(newUrl);
                        if (newPane && newPane.slug !== $scope.panes[selectedIndex].slug) {
                            $scope.selectTab(newPane, false);
                        }
                    });
                }
            }],
            link: function(scope) {
                // doing this in the link because it's executed after it's children (panes) link
                // so we are sure to have all panes declared
                scope.selectDefaultTab();
                scope.linkingDone = true;
            }
        };
    });

    mod.directive('odsPane', ['translate', '$filter', function (translate, $filter) {
        /**
         * @ngdoc directive
         * @name ods.core.directive:odsPane
         * @restrict E
         * @requires odsTabs
         *
         * @param {string} title The title of the pane, as displayed in the tab.
         * @param {string} [slug=slugified title] The slug to use as tab and as url. If not set, the slugified version of the title is used as tab name.
         * @param {string} icon The font-awesome icon name used for the tab, without the 'fa-' prefix.
         *
         * @param {boolean} [paneAutoUnload=false] Whether to destroy and rebuild the pane content at deselection/selection.
         * @param {string} [tabClass] Class names that will be added to the pane wrapper.
         * @param {integer} [count] A number to be displayed alongside the title in the tab.
         * @param {boolean} [doNotRegister=false] If true, then the pane won't be registered with its parent tabs component so that it really doesn't exists.
         */
        return {
            require: '^odsTabs',
            restrict: 'E',
            transclude: true,
            template: '' +
            '<div class="ods-tabs__pane" role="tabpanel"' +
            '     ng-class="{\'ods-tabs__pane--active\':struct.selected,' +
            '                \'ods-tabs__pane--horizontal\': !layout || layout == \'horizontal\',' +
            '                \'ods-tabs__pane--simple-nav\': layout == \'simple-nav\'}">' +
            '    <div ng-if="shown || !struct.autoUnload" ng-transclude>' +
            '    </div>' +
            '</div>',
            replace: true,
            scope: true,
            link: function (scope, element, attrs, tabsCtrl) {
                if (scope.$eval(attrs.doNotRegister) === true) {
                    scope.shown = false;
                    scope.struct = {
                        autoUnload:true,
                        hidden: true
                    };
                    return;
                }

                scope.layout = tabsCtrl.getLayout();
                scope.struct = {
                    title: translate(attrs.title),
                    slug: attrs.slug || $filter('slugify')(attrs.title),
                    icon: attrs.icon,
                    hidden: (
                        ('ngShow' in attrs && !scope.$eval(attrs.ngShow)) ||
                        ('ngHide' in attrs && scope.$eval(attrs.ngHide))
                    ),
                    tabClass: attrs.tabClass,
                    autoUnload: attrs.paneAutoUnload == 'true'
                };
                // Removing the title from the element itself, to prevent a tooltip when hovering anywhere over
                // the content.
                element.removeAttr('title');

                // register itself
                var position;
                var parent = element[0].parentNode;
                for (var i=0; i<parent.children.length; i++) {
                    if (parent.children[i] === element[0]) {
                        position = i;
                        break;
                    }
                }
                tabsCtrl.addPane(scope.struct, position);

                scope.$watch(function () {
                    return (
                        ('ngShow' in attrs && !scope.$eval(attrs.ngShow)) ||
                        ('ngHide' in attrs && scope.$eval(attrs.ngHide))
                    );
                }, function (nv, ov) {
                    scope.struct.hidden = nv;
                });

                scope.$watch(attrs.count, function(nv) {
                    if (angular.isDefined(nv)) {
                        scope.struct.count = nv;
                    }
                }, true);

                scope.$watch(function() {
                    return attrs.icon;
                }, function(nv) {
                    if (angular.isDefined(nv)) {
                        scope.struct.icon = nv;
                    }
                }, true);

                scope.$watch(function() {
                    return attrs.tabClass;
                }, function(nv) {
                    if (angular.isDefined(nv)) {
                        scope.struct.tabClass = nv;
                    }
                }, true);

                /*
                We need to have a digest cycle between the selection and the moment we truly display the content, because
                the selection triggers the display: block in the CSS; if we run the content at the same time, it may be
                run before it is truly displayed in the page, which can cause issues with Leaflet for example (it needs to know
                where it is in the page when it is initialized).
                 */
                scope.$watch('struct.selected', function(nv) {
                    if (nv) {
                        scope.$applyAsync(function() {
                            scope.shown = true;
                        });
                    } else {
                        scope.shown = false;
                    }
                });
            }
        };
    }]);
}());

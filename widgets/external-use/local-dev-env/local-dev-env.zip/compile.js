var args = process.argv.slice(2);

if (args.length <= 1) {
    process.stdout.write("Missing param.\nUsage: node compile.js ./views/page.ejs output.html\n");
    process.exit(1);
}

ejs_file = args[0];
output_file = args[1];

const fs = require('fs');
const ejs = require('ejs');
const path = require('path');
const config = require('./config');

var walk = function(dir) {
    var results = [];
    var list = fs.readdirSync(dir);
    list.forEach(function(file) {
        file = dir + '/' + file;
        var stat = fs.statSync(file);
        if (stat && stat.isDirectory()) {
            /* Recurse into a subdirectory */
            results = results.concat(walk(file));
        } else {
            /* Is a file */
            var finalfilepath = file.replace('static/','')
            results.push(finalfilepath);
        }
    });
    return results;
}

/* EJS Compiler and path resolver */
ejs.compileFile = function(filePath, options) {
    let templatePath = filePath;
    if (options && options.root) templatePath = path.resolve(options.root, templatePath);
    const templateStr = ejs.fileLoader(templatePath, 'utf8');
    options = Object.assign({ filename: templatePath }, options);
    return ejs.compile(templateStr, {
        'filename': filePath
    });
}

const templatePath = path.resolve(__dirname, ejs_file);
const template = ejs.compileFile(templatePath);
const output = template({
    'apikeys': config.API_KEYS,
    'defaultdomain': config.DEFAULT_DOMAIN_URL,
    'jsscripts': walk('static/ods-internal/scripts')
});

const data = new Uint8Array(Buffer.from(output));

fs.writeFile(output_file, data, (err) => {
    if (err) throw err;
    process.stdout.write('HTML successfully compiled and generated!\n');
});
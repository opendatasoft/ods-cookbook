module.exports = {
    // gulp update parameters
    ODS_PORTAL_DOMAIN_ID: '<DOMAIN ID>',
    ODS_USERNAME: '<USERNAME>',
    ODS_PASSWORD: '<PASSWORD>',
    PAGE_ID: '<ID>',

    // HTTP Intercept queries to add domain or apikey params to dataset-context
    API_KEYS: [
        {
            'domain':'mydomainID',
            'apikey':'APIKEY HERE',
        },
    ],
    DEFAULT_DOMAIN_URL: 'DEFAULT DOMAIN URL', // should be like : https://data.opendatasoft.com/

    // Command-line defaults, gulp compile
    DEFAULT_EJSFILE: 'views/page.ejs',
    DEFAULT_LESSFILE: 'static/stylesheets/page.less',
    DEFAULT_OUTPUT_HTML_FILE: 'page.html',
    DEFAULT_OUTPUT_CSS_FILE: 'page.css',

    // Adv. settings
    WATCH_DIRS: [
        "./static/**/*.less",
        "./static/**/*.css",
        "./views/**/*.html",
        "./views/**/*.ejs"
    ],
    BROWSER: "google chrome",

    // You usually shouldn't have to edit these
    ODS_PORTAL_SUFFIX: '.opendatasoft.com',
    SERVER_PORT: 9090,
    OUTPUT_DIR: 'output'
};
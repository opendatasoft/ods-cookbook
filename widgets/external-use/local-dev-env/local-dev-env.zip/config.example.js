var project_config = require('./config.project');

module.exports = {
    // gulp update parameters
    ODS_PORTAL_DOMAIN_ID: project_config.ODS_PORTAL_DOMAIN_ID,
    DEFAULT_DOMAIN_URL: project_config.DEFAULT_DOMAIN_URL,

    ODS_USERNAME: '<USERNAME>',
    ODS_PASSWORD: '<PASSWORD>',

    // List of pages, used by the gulp server and gulp update/compile commands
    PAGES: [
        // most advanced way to declare a page: a name, it's index html and css to load locally the page, and it's content to push it through the API on ODS
        // index.html and index.css are used locally by gulp server
        // content.html and content.css are used to push the content to ODS pages through the API, and therefore with gulp update-all command
        // name correspond to the page locally but also to the page id on the platform.
        {
            name: 'pageid',
            index: {
                html: 'views/index-page.ejs',
                css: 'static/stylesheets/index-page.scss'
            },
            content: {
                html: 'views/page.ejs',
                css: 'static/stylesheets/page.scss'
            }
        },
        // Simplest way to declare a page, a name, and an index html file
        /*{
            name: 'test',
            index: {
                html: 'views/test.ejs',
            }
        }*/
    ],

    // HTTP Intercept queries to add domain or apikey params to dataset-context
    API_KEYS: [
        {
            'domain':'mydomainID',
            'apikey':'APIKEY HERE',
        },
    ],

    // Adv. settings
    WATCH_DIRS: [
        "./views/**/*.html",
        "./views/**/*.ejs"
    ],
    BROWSER: "google chrome",

    // You usually shouldn't have to edit these
    ODS_PORTAL_SUFFIX: '.opendatasoft.com',
    SERVER_PORT: 9090,
    OUTPUT_DIR: 'output'
};
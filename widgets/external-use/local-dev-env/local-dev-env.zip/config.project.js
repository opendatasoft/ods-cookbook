var project_config = require('./config.project');

module.exports = {
    ODS_PORTAL_DOMAIN_ID: '<DOMAIN ID>',
    DEFAULT_DOMAIN_URL: 'DEFAULT DOMAIN URL', // should be like : https://data.opendatasoft.com/

    // List of pages, used by the gulp server and gulp update/compile commands.
    // the name/id/slug of the page MUST CORRESPOND to the page id on your Opendatasoft portal.
    // it must also correspond to the ejs file name and scss file name.
    PAGES: ['pageid'],
};
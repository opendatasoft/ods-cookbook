var project_config = require('./config.project');

module.exports = {
    ODS_PORTAL_DOMAIN_ID: '<DOMAIN ID>',
    DEFAULT_DOMAIN_URL: 'DEFAULT DOMAIN URL', // should be like : https://data.opendatasoft.com/

    // List of pages, used by the gulp server and gulp update/compile commands
    PAGES: [
        // most advanced way to declare a page: a name, it's index html and css to load locally the page, and it's content to push it through the API on ODS
        // index.html and index.css are used locally by gulp server
        // content.html and content.css are used to push the content to ODS pages through the API, and therefore with gulp update-all command
        // name correspond to the page locally but also to the page id on the platform.
        {
            name: 'pageid',
            index: {
                html: 'views/index-page.ejs',
                css: 'static/stylesheets/index-page.scss'
            },
            content: {
                html: 'views/page.ejs',
                css: 'static/stylesheets/page.scss'
            }
        },
        // Simplest way to declare a page, a name, and an index html file
        /*{
            name: 'test',
            index: {
                html: 'views/test.ejs',
            }
        }*/
    ],
};
var yargs = require('yargs');
var argv = yargs.argv;
var config = require('./config');

const path = require('path');
const fs = require('fs');
var walk = function(dir) {
    var results = [];
    var list = fs.readdirSync(dir);
    list.forEach(function(file) {
        file = dir + '/' + file;
        var stat = fs.statSync(file);
        if (stat && stat.isDirectory()) {
            /* Recurse into a subdirectory */
            results = results.concat(walk(file));
        } else {
            /* Is a file */
            var finalfilepath = file.replace('static/','')
            results.push(finalfilepath);
        }
    });
    return results;
}


let express = require('express');
let app = express();

app.set('view engine', 'ejs');

app.get(['/', '/:x'], (req, res) => {
    res.render('index', {
        'apikeys': config.API_KEYS,
        'defaultdomain': config.DEFAULT_DOMAIN_URL,
        'jsscripts': walk('static/ods-internal/scripts')
    });
});

app.use(express.static('static'));

app.listen(argv.port, () => console.log('ExpressJS App listening on :' + argv.port + ' !'));